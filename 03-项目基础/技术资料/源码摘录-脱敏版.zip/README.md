# 星膳智搜源码摘录

本包选自 2026 年 10 月 1 日归档的 AI 端源码，用于院赛前期基础与技术方案说明。收录的八个 Python 文件保留原始字节。

## 收录范围

- `src/agent_core/graph.py` 展示代理流程、证据检索、风险审核和结果汇总。
- `src/agent_core/agent_policies.py`、`interfaces.py`、`contracts.py` 和 `state.py` 定义策略、工具接口、数据模型和工作流状态。
- `src/agent_core/pubmed_query_translation.py` 展示 PubMed 检索词处理。
- `src/mobile_chat_contract.py` 和 `src/photo_recognition_contract.py` 定义小程序问答与图片识别接口的数据结构。

本包适合源码查阅。完整运行还需要原工程的网络适配器、模型、数据库、向量检索服务和小程序。摘录的协议文件仅含数据结构及校验逻辑。

## 核验

八个源码文件与历史归档逐字节一致，并通过 Python 静态语法检查。文件哈希见 `SHA256SUMS.txt`。
