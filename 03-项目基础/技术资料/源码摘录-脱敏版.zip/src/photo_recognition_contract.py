from typing import Literal

from pydantic import BaseModel, Field


RiskStatus = Literal["green", "yellow", "red"]


class PhotoIngredient(BaseModel):
    name: str
    normalized_name: str
    status: RiskStatus
    reasons: list[str] = Field(default_factory=list)


class PhotoRecognitionData(BaseModel):
    request_id: str
    session_id: str | None = None
    is_mock: bool = False

    recognized_text: str = ""
    ingredients: list[PhotoIngredient] = Field(default_factory=list)

    overall_status: RiskStatus = "yellow"
    warnings: list[str] = Field(default_factory=list)
    alternatives: list[str] = Field(default_factory=list)


class PhotoRecognitionResponse(BaseModel):
    success: bool
    code: str
    message: str
    data: PhotoRecognitionData
