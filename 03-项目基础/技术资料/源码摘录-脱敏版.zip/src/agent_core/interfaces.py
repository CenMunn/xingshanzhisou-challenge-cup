"""Stable adapter interfaces for future Agent tool implementations.

The protocols depend only on the backend-neutral contracts.  Real adapters may
later call local Python modules or server APIs without exposing those details to
the orchestration layer.
"""

from typing import Protocol, runtime_checkable

from .contracts import (
    PubMedToolInput,
    PubMedToolResult,
    RAGToolInput,
    RAGToolResult,
    RecipeToolInput,
    RecipeToolResult,
    SafetyRestrictionToolInput,
    SafetyRestrictionToolResult,
)


@runtime_checkable
class RAGToolAdapter(Protocol):
    """Retrieve local knowledge through a backend-neutral async boundary."""

    async def run(self, tool_input: RAGToolInput) -> RAGToolResult:
        ...


@runtime_checkable
class PubMedToolAdapter(Protocol):
    """Retrieve structured PubMed evidence through an async boundary."""

    async def run(self, tool_input: PubMedToolInput) -> PubMedToolResult:
        ...


@runtime_checkable
class RecipeToolAdapter(Protocol):
    """Query recipe, plan, or food candidates without prescribing writes."""

    async def run(self, tool_input: RecipeToolInput) -> RecipeToolResult:
        ...


@runtime_checkable
class SafetyRestrictionToolAdapter(Protocol):
    """Check food restrictions independently from recipe retrieval."""

    async def run(
        self, tool_input: SafetyRestrictionToolInput
    ) -> SafetyRestrictionToolResult:
        ...
