"""Minimal LangGraph orchestration with injected tools and agent policies."""

from collections.abc import Hashable
from pydantic import ValidationError

from langgraph.graph import END, START, StateGraph
from langgraph.graph.state import CompiledStateGraph

from .agent_policies import NutritionistPolicy, SafetyPolicy, SupervisorPolicy
from .contracts import (
    PubMedToolInput,
    RAGToolInput,
    RecipeIntent,
    RecipeToolInput,
    ReferenceRecord,
    SafetyRestrictionToolInput,
    SourceKind,
    SourceRecord,
    ToolStatus,
    ToolErrorKind,
)
from .contracts import UserContextProvenance
from .interfaces import (
    PubMedToolAdapter,
    RAGToolAdapter,
    RecipeToolAdapter,
    SafetyRestrictionToolAdapter,
)
from .state import AgentError, AgentIntent, AgentStage, AgentState, SafetyStatus, ToolName
from .llm_policies import LLMPolicyError
from .llm_transport import LLMNetworkError, LLMHTTPError, LLMResponseError


_MAX_REVISIONS = 2
POLICY_FAILURE_FALLBACK = "当前无法可靠完成回答，请稍后重试。"
_MAX_REVISION_REJECTION = (
    "Fake安全拒答：离线编排测试已达到最大修订次数，未输出未经审核草稿。"
)
_TOOL_ERROR_REJECTION = (
    "Fake安全拒答：离线编排测试检测到工具错误，未输出正常建议。"
)
RESTRICTION_UNAVAILABLE = "当前无法可靠确认该具体食材是否符合您的饮食限制。"


def _tool_error(tool: ToolName, result: object) -> AgentError:
    error = getattr(result, "error", None)
    kind = getattr(getattr(error, "kind", None), "value", "unknown")
    message = getattr(error, "message", f"{tool.value} tool failed")
    retryable = bool(getattr(error, "retryable", False))
    return AgentError(
        stage=AgentStage.TOOL,
        code=f"{tool.value}_{kind}",
        message=message,
        retryable=retryable,
    )


def _safety_rejection(message: str) -> AgentError:
    return AgentError(
        stage=AgentStage.SAFETY,
        code="safety_reject",
        message=message,
        retryable=False,
    )


def _policy_failure(
    state: AgentState, stage: AgentStage, exc: Exception
) -> dict[str, object]:
    """Preserve prior errors without exposing exception messages or endpoints."""
    kind = ToolErrorKind.INTERNAL
    retryable = False
    if isinstance(exc, LLMNetworkError):
        kind, retryable = ToolErrorKind.NETWORK, True
    elif isinstance(exc, LLMHTTPError):
        kind = ToolErrorKind.UPSTREAM
        retryable = exc.status_code in {408, 429} or (
            exc.status_code is not None and exc.status_code >= 500
        )
    elif isinstance(exc, (LLMResponseError, LLMPolicyError, ValidationError)):
        kind = ToolErrorKind.PARSE
    error = AgentError(
        stage=stage,
        code=f"{stage.value}_policy_{kind.value}",
        message=f"{stage.value}_policy failed; response withheld.",
        retryable=retryable,
    )
    return {
        "errors": [*state.errors, error, _safety_rejection(POLICY_FAILURE_FALLBACK)],
        "safety_status": SafetyStatus.REJECT,
        "draft_answer": None,
        "final_answer": None,
    }


def build_agent_graph(
    *,
    rag_tool: RAGToolAdapter,
    pubmed_tool: PubMedToolAdapter,
    recipe_tool: RecipeToolAdapter,
    safety_restriction_tool: SafetyRestrictionToolAdapter,
    supervisor_policy: SupervisorPolicy,
    nutritionist_policy: NutritionistPolicy,
    safety_policy: SafetyPolicy,
) -> CompiledStateGraph:
    """Build and compile the injectable offline-capable orchestration graph."""

    async def supervisor(state: AgentState) -> dict[str, object]:
        try:
            decision = await supervisor_policy.decide(state)
            required_tools = list(dict.fromkeys(decision.required_tools))
            if (decision.intent == AgentIntent.RESTRICTION_CHECK
                    and ToolName.SAFETY_RESTRICTION not in required_tools):
                required_tools.append(ToolName.SAFETY_RESTRICTION)
            return {
                "intent": decision.intent,
                "required_tools": required_tools,
            }
        except Exception as exc:
            return _policy_failure(state, AgentStage.SUPERVISOR, exc)

    async def evidence(state: AgentState) -> dict[str, object]:
        update: dict[str, object] = {}
        errors = list(state.errors)
        sources = list(state.sources)
        references = list(state.references)

        if ToolName.RAG in state.required_tools:
            rag_result = await rag_tool.run(RAGToolInput(query=state.question))
            update["rag_result"] = rag_result
            if rag_result.status == ToolStatus.ERROR:
                errors.append(_tool_error(ToolName.RAG, rag_result))
            else:
                sources.extend(rag_result.sources)
                references.extend(rag_result.references)

        if ToolName.PUBMED in state.required_tools:
            pubmed_result = await pubmed_tool.run(
                PubMedToolInput(query=state.question)
            )
            update["pubmed_result"] = pubmed_result
            if pubmed_result.status == ToolStatus.ERROR:
                errors.append(_tool_error(ToolName.PUBMED, pubmed_result))
            elif pubmed_result.status == ToolStatus.SUCCESS:
                for article in pubmed_result.articles:
                    source_id = f"pubmed:{article.pmid}"
                    sources.append(
                        SourceRecord(
                            source_id=source_id,
                            label=article.title or f"PubMed {article.pmid}",
                            kind=SourceKind.PUBMED,
                            locator=article.url or None,
                        )
                    )
                    references.append(
                        ReferenceRecord(
                            citation=article.title or f"PubMed {article.pmid}",
                            external_id=article.pmid,
                            title=article.title or None,
                            url=article.url or None,
                            source_id=source_id,
                        )
                    )

        update.update(errors=errors, sources=sources, references=references)
        return update

    async def recipe(state: AgentState) -> dict[str, object]:
        result = await recipe_tool.run(
            RecipeToolInput(
                # FOOD_CANDIDATES requires at least one verified guideline id,
                # but the frozen AgentState has no such field.  The unfiltered
                # template query is the only supported read-only default that
                # can be constructed faithfully from the current graph state.
                intent=(
                    RecipeIntent.CURRENT_PLAN
                    if state.user_context is not None
                    and state.user_context.provenance
                    is UserContextProvenance.SERVER_VERIFIED
                    else RecipeIntent.TEMPLATE_CANDIDATES
                ),
                user_context=state.user_context,
            )
        )
        errors = list(state.errors)
        if result.status == ToolStatus.ERROR:
            errors.append(_tool_error(ToolName.RECIPE, result))
        return {"recipe_result": result, "errors": errors}

    async def restriction(state: AgentState) -> dict[str, object]:
        food_ids: list[int] = []
        if state.recipe_result:
            candidates = list(state.recipe_result.foods)
            for recipe_candidate in state.recipe_result.recipes:
                candidates.extend(recipe_candidate.foods)
            food_ids = list(
                dict.fromkeys(
                    candidate.food_id
                    for candidate in candidates
                    if candidate.food_id is not None
                )
            )
        result = await safety_restriction_tool.run(
            SafetyRestrictionToolInput(
                user_context=state.user_context,
                food_ids=food_ids,
                question=state.question,
            )
        )
        errors = list(state.errors)
        if result.status == ToolStatus.ERROR:
            errors.append(_tool_error(ToolName.SAFETY_RESTRICTION, result))
        return {"restriction_result": result, "errors": errors}

    async def nutritionist(state: AgentState) -> dict[str, object]:
        # A complete verified restriction check is a deterministic
        # personalized safety result. "blocked" means the food should
        # not be consumed; it does NOT mean the assistant must refuse
        # to answer the user's question.
        result = state.restriction_result

        if (
            state.intent == AgentIntent.RESTRICTION_CHECK
            and result is not None
            and result.status == ToolStatus.SUCCESS
            and result.allowed is not None
            and not result.unknown_food_ids
        ):
            if result.allowed:
                draft = (
                    "根据当前已验证的个人饮食限制记录，"
                    "您询问的食材均处于可食范围内。"
                    "如果近期医嘱或饮食限制已经发生变化，"
                    "请以最新记录为准。"
                )
            else:
                draft = (
                    "根据当前已验证的个人饮食限制记录，"
                    "您询问的食材中存在禁食项，因此不建议食用。"
                )

            return {
                "draft_answer": draft,
                "safety_status": SafetyStatus.PENDING,
            }

        try:
            draft = await nutritionist_policy.draft(state)
        except Exception as exc:
            return _policy_failure(
                state,
                AgentStage.NUTRITIONIST,
                exc,
            )

        return {
            "draft_answer": draft,
            "safety_status": SafetyStatus.PENDING,
        }

    async def safety(state: AgentState) -> dict[str, object]:
        errors = list(state.errors)

        if errors:
            errors.append(
                _safety_rejection(_TOOL_ERROR_REJECTION)
            )
            return {
                "safety_status": SafetyStatus.REJECT,
                "errors": errors,
            }

        if ToolName.SAFETY_RESTRICTION in state.required_tools:
            result = state.restriction_result

            candidates = []

            if state.recipe_result:
                candidates.extend(
                    state.recipe_result.foods
                )

                for candidate in state.recipe_result.recipes:
                    candidates.extend(candidate.foods)

            recipe_food_ids = {
                food.food_id
                for food in candidates
                if food.food_id is not None
            }

            checked_ids = (
                {
                    item.food_id
                    for item in result.decisions
                }
                if result is not None
                else set()
            )

            target_food_ids = recipe_food_ids

            if (
                not target_food_ids
                and state.intent
                == AgentIntent.RESTRICTION_CHECK
            ):
                target_food_ids = checked_ids

            incomplete = (
                not target_food_ids
                or result is None
                or result.status != ToolStatus.SUCCESS
                or result.allowed is None
                or bool(result.unknown_food_ids)
                or not target_food_ids.issubset(
                    checked_ids
                )
            )

            if incomplete:
                errors.append(
                    AgentError(
                        stage=AgentStage.SAFETY,
                        code="restriction_unavailable",
                        message=RESTRICTION_UNAVAILABLE,
                    )
                )
                errors.append(
                    _safety_rejection(
                        RESTRICTION_UNAVAILABLE
                    )
                )

                return {
                    "safety_status": SafetyStatus.REJECT,
                    "errors": errors,
                }

            # Pure restriction questions are already decided by
            # authenticated deterministic Java restriction data.
            #
            # allowed=True  -> safe positive answer
            # allowed=False -> safe negative answer
            #
            # Neither case is a reason to refuse answering.
            if state.intent == AgentIntent.RESTRICTION_CHECK:
                if (
                    not state.draft_answer
                    or not state.draft_answer.strip()
                ):
                    errors.append(
                        _safety_rejection(
                            RESTRICTION_UNAVAILABLE
                        )
                    )
                    return {
                        "safety_status": SafetyStatus.REJECT,
                        "errors": errors,
                    }

                return {
                    "safety_status": SafetyStatus.PASS
                }

        # General knowledge and recipe-generation answers still pass
        # through the LLM safety reviewer.
        try:
            decision = await safety_policy.review(state)
        except Exception as exc:
            return _policy_failure(
                state,
                AgentStage.SAFETY,
                exc,
            )

        if decision.status == SafetyStatus.REVISE:
            if state.revision_count < _MAX_REVISIONS:
                return {
                    "safety_status": SafetyStatus.REVISE,
                    "revision_count":
                        state.revision_count + 1,
                }

            errors.append(
                _safety_rejection(
                    _MAX_REVISION_REJECTION
                )
            )

            return {
                "safety_status": SafetyStatus.REJECT,
                "errors": errors,
            }

        if decision.status == SafetyStatus.REJECT:
            errors.append(
                _safety_rejection(
                    decision.rejection_text
                    or "Fake安全拒答。"
                )
            )

            return {
                "safety_status": SafetyStatus.REJECT,
                "errors": errors,
            }

        return {
            "safety_status": SafetyStatus.PASS
        }

    async def finalize(state: AgentState) -> dict[str, object]:
        if state.safety_status == SafetyStatus.PASS:
            return {"final_answer": state.draft_answer}
        if state.safety_status == SafetyStatus.REJECT:
            rejection = next(
                (
                    error.message
                    for error in reversed(state.errors)
                    if error.stage == AgentStage.SAFETY
                    and error.code == "safety_reject"
                ),
                "Fake安全拒答：离线编排测试未产生可安全输出的答案。",
            )
            return {"final_answer": rejection}
        raise ValueError("finalize requires pass or reject safety status")

    def after_supervisor(state: AgentState) -> Hashable:
        if state.safety_status == SafetyStatus.REJECT:
            return "finalize"
        if ToolName.RECIPE in state.required_tools:
            return "recipe"
        if ToolName.SAFETY_RESTRICTION in state.required_tools:
            return "restriction"
        if {ToolName.RAG, ToolName.PUBMED}.intersection(state.required_tools):
            return "evidence"
        return "nutritionist"

    def after_recipe(state: AgentState) -> Hashable:
        if ToolName.SAFETY_RESTRICTION in state.required_tools:
            return "restriction"
        if {ToolName.RAG, ToolName.PUBMED}.intersection(state.required_tools):
            return "evidence"
        return "nutritionist"

    def after_restriction(state: AgentState) -> Hashable:
        if {ToolName.RAG, ToolName.PUBMED}.intersection(state.required_tools):
            return "evidence"
        return "nutritionist"

    def after_safety(state: AgentState) -> Hashable:
        if state.safety_status == SafetyStatus.REVISE:
            return "nutritionist"
        return "finalize"

    def after_nutritionist(state: AgentState) -> Hashable:
        return "finalize" if state.safety_status == SafetyStatus.REJECT else "safety"

    graph = StateGraph(AgentState)
    graph.add_node("supervisor", supervisor)
    graph.add_node("evidence", evidence)
    graph.add_node("recipe", recipe)
    graph.add_node("restriction", restriction)
    graph.add_node("nutritionist", nutritionist)
    graph.add_node("safety", safety)
    graph.add_node("finalize", finalize)

    graph.add_edge(START, "supervisor")
    graph.add_conditional_edges(
        "supervisor",
        after_supervisor,
        {
            "finalize": "finalize",
            "recipe": "recipe",
            "restriction": "restriction",
            "evidence": "evidence",
            "nutritionist": "nutritionist",
        },
    )
    graph.add_conditional_edges(
        "recipe",
        after_recipe,
        {
            "restriction": "restriction",
            "evidence": "evidence",
            "nutritionist": "nutritionist",
        },
    )
    graph.add_conditional_edges(
        "restriction",
        after_restriction,
        {"evidence": "evidence", "nutritionist": "nutritionist"},
    )
    graph.add_edge("evidence", "nutritionist")
    graph.add_conditional_edges(
        "nutritionist", after_nutritionist,
        {"finalize": "finalize", "safety": "safety"},
    )
    graph.add_conditional_edges(
        "safety",
        after_safety,
        {"nutritionist": "nutritionist", "finalize": "finalize"},
    )
    graph.add_edge("finalize", END)
    return graph.compile()
