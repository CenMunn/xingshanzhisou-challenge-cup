"""Pure PubMed query translation for Agent-side retrieval.

Derived from the existing project's Chinese-to-English PubMed keyword mapping.
This module performs no HTTP, persistence, or model calls.
"""

import re


_ZH_TO_EN_KEYWORDS = {'自闭症': ['autism spectrum disorder', 'ASD', 'autism'],
 '孤独症': ['autism spectrum disorder', 'ASD', 'autism'],
 '阿斯伯格': ['Asperger syndrome'],
 '无麸质': ['gluten-free diet', 'GFCF diet', 'gluten free'],
 '无酪蛋白': ['casein-free diet', 'GFCF diet', 'casein free'],
 '生酮饮食': ['ketogenic diet'],
 '地中海饮食': ['Mediterranean diet'],
 '食物': ['food', 'foods', 'dietary'],
 '食谱': ['meal plan', 'dietary pattern', 'diet'],
 '饮食': ['diet', 'dietary intake'],
 '营养': ['nutrition', 'nutritional status'],
 '避免': ['avoidance', 'avoid', 'restriction'],
 '禁忌': ['contraindication', 'food restriction', 'avoid'],
 '不能吃': ['food restriction', 'food avoidance'],
 '过敏': ['food allergy', 'food intolerance', 'hypersensitivity'],
 '挑食': ['food selectivity', 'picky eating', 'food refusal'],
 '偏食': ['food selectivity', 'restricted eating'],
 '添加剂': ['food additives', 'artificial additives', 'preservatives'],
 '糖': ['sugar', 'refined sugar', 'sucrose'],
 '加工食品': ['processed food', 'ultra-processed food'],
 '肠道菌群': ['gut microbiota', 'gut microbiome', 'intestinal microbiota'],
 '益生菌': ['probiotics', 'probiotic supplementation'],
 '益生元': ['prebiotics'],
 '粪菌移植': ['fecal microbiota transplantation', 'FMT'],
 '肠脑轴': ['gut-brain axis'],
 '短链脂肪酸': ['short-chain fatty acids', 'SCFAs', 'butyrate'],
 '双歧杆菌': ['Bifidobacterium'],
 '乳酸杆菌': ['Lactobacillus'],
 '阿克曼菌': ['Akkermansia muciniphila'],
 '肠漏': ['leaky gut', 'intestinal permeability'],
 '便秘': ['constipation', 'gastrointestinal'],
 '腹泻': ['diarrhea', 'gastrointestinal symptoms'],
 '胃肠': ['gastrointestinal', 'GI symptoms'],
 '维生素D': ['vitamin D', 'vitamin D deficiency', 'cholecalciferol'],
 '维生素B': ['vitamin B', 'B vitamins', 'folate'],
 '叶酸': ['folate', 'folic acid'],
 '铁': ['iron', 'iron deficiency'],
 '锌': ['zinc', 'zinc deficiency'],
 '镁': ['magnesium'],
 '钙': ['calcium'],
 'omega-3': ['omega-3 fatty acids', 'DHA', 'fish oil'],
 'DHA': ['DHA', 'docosahexaenoic acid', 'omega-3'],
 '饮食干预': ['dietary intervention', 'nutritional intervention'],
 '营养干预': ['nutritional intervention', 'dietary supplementation'],
 '补充剂': ['supplementation', 'dietary supplement'],
 '行为': ['behavior', 'behavioral symptoms'],
 '睡眠': ['sleep', 'sleep disturbance'],
 '感觉敏感': ['sensory sensitivity', 'sensory processing'],
 '焦虑': ['anxiety'],
 '注意力': ['attention', 'ADHD'],
 '语言': ['language', 'communication'],
 '社交': ['social behavior', 'social communication'],
 '儿童': ['children', 'pediatric', 'child'],
 '幼儿': ['toddler', 'young children', 'preschool'],
 '青少年': ['adolescent', 'teenager']}


def contains_chinese(text: str) -> bool:
    return any("\u4e00" <= ch <= "\u9fff" for ch in text)


def translate_query_to_pubmed_terms(query: str) -> tuple[str, str]:
    collected: list[list[str]] = []
    query_lower = query.lower()

    for zh_word, en_list in _ZH_TO_EN_KEYWORDS.items():
        if zh_word.lower() in query_lower:
            collected.append(list(en_list[:3]))

    stopwords = {
        "the", "a", "an", "is", "are", "in", "on", "of",
        "for", "to", "and", "or", "what", "how", "why",
        "should", "can", "does", "which",
    }

    existing_lower = {
        term.lower()
        for group in collected
        for term in group
    }

    for word in re.findall(r"[a-zA-Z]{3,}", query):
        lowered = word.lower()
        if lowered not in stopwords and lowered not in existing_lower:
            collected.append([word])
            existing_lower.add(lowered)

    if not collected:
        fallback = query.strip()
        return (
            f'"{fallback}"[Title/Abstract]',
            f'"{fallback}"[Title/Abstract]',
        )

    strict_parts = [
        f'"{group[0]}"[Title/Abstract]'
        for group in collected[:4]
    ]
    strict = " AND ".join(strict_parts)

    loose_parts: list[str] = []
    for group in collected[:3]:
        if len(group) == 1:
            loose_parts.append(f'"{group[0]}"[Title/Abstract]')
        else:
            inner = " OR ".join(
                f'"{term}"[Title/Abstract]'
                for term in group
            )
            loose_parts.append(f"({inner})")

    loose = " AND ".join(loose_parts)

    return strict, loose


def build_pubmed_search_terms(
    query: str,
    min_year: int | None,
) -> list[str]:
    """Return ordered unique ESearch terms.

    Chinese:
        strict -> loose -> first core group

    Non-Chinese:
        preserve the original query unchanged.
    """

    query = query.strip()

    if contains_chinese(query):
        strict, loose = translate_query_to_pubmed_terms(query)
        candidates = [
            strict,
            loose,
            loose.split(" AND ")[0],
        ]
    else:
        candidates = [query]

    unique: list[str] = []

    for candidate in candidates:
        candidate = candidate.strip()
        if not candidate or candidate in unique:
            continue

        if min_year is not None:
            candidate = (
                f"({candidate}) AND "
                f"({min_year}:9999[pdat])"
            )

        if candidate not in unique:
            unique.append(candidate)

    return unique
