"""Backend-neutral contracts for future Agent tools.

These models describe adapter boundaries only. They do not import or call the
local RAG, PubMed, Java, database, or model-service implementations.
"""

from datetime import date
from enum import Enum
from typing import Annotated, List, Literal, Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StrictStr,
    StringConstraints,
    model_validator,
)


class ContractModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


NonEmptyText = Annotated[
    StrictStr, StringConstraints(strip_whitespace=True, min_length=1)
]
QuestionText = Annotated[
    StrictStr, StringConstraints(strip_whitespace=True, min_length=1, max_length=2000)
]


class ToolStatus(str, Enum):
    SUCCESS = "success"
    EMPTY = "empty"
    ERROR = "error"


class ToolErrorKind(str, Enum):
    INVALID_INPUT = "invalid_input"
    UNAVAILABLE = "unavailable"
    NETWORK = "network_error"
    PARSE = "parse_error"
    UPSTREAM = "upstream_error"
    INTERNAL = "internal_error"


class ToolError(ContractModel):
    kind: ToolErrorKind
    message: NonEmptyText
    retryable: bool = False


class SourceKind(str, Enum):
    LOCAL_DOCUMENT = "local_document"
    WECHAT = "wechat"
    PUBMED = "pubmed"
    UNKNOWN = "unknown"


class SourceRecord(ContractModel):
    """Provenance location; it is not a formatted citation."""

    source_id: Optional[str] = None
    label: NonEmptyText
    kind: SourceKind = SourceKind.UNKNOWN
    locator: Optional[str] = None


class ReferenceRecord(ContractModel):
    """User-facing citation data, kept separate from source provenance."""

    citation: NonEmptyText
    external_id: Optional[str] = None
    title: Optional[str] = None
    url: Optional[str] = None
    source_id: Optional[str] = None


def _validate_error_status(status: ToolStatus, error: Optional[ToolError]) -> None:
    if status == ToolStatus.ERROR and error is None:
        raise ValueError("error status requires error details")
    if status != ToolStatus.ERROR and error is not None:
        raise ValueError("non-error status cannot contain error details")


class RAGFilters(ContractModel):
    source_scope: Literal["all", "local", "wechat"] = "all"
    accounts: List[str] = Field(default_factory=list)
    date_from: Optional[date] = None
    date_to: Optional[date] = None

    @model_validator(mode="after")
    def validate_date_range(self) -> "RAGFilters":
        if self.date_from and self.date_to and self.date_from > self.date_to:
            raise ValueError("date_from cannot be later than date_to")
        return self


class RAGToolInput(ContractModel):
    query: QuestionText
    filters: RAGFilters = Field(default_factory=RAGFilters)
    top_k: int = Field(default=5, ge=1, le=50)


class RAGItemMetadata(ContractModel):
    source_type: Optional[str] = None
    account: Optional[str] = None
    publish_date: Optional[str] = None
    chunk_index: Optional[int] = None


class RAGItem(ContractModel):
    item_id: Optional[str] = None
    rank: int = Field(ge=1)
    text: NonEmptyText
    source: Optional[SourceRecord] = None
    metadata: RAGItemMetadata = Field(default_factory=RAGItemMetadata)
    vector_distance: Optional[float] = None
    rerank_score: Optional[float] = None


class RAGToolResult(ContractModel):
    status: ToolStatus
    context: str = ""
    sources: List[SourceRecord] = Field(default_factory=list)
    references: List[ReferenceRecord] = Field(default_factory=list)
    items: List[RAGItem] = Field(default_factory=list)
    error: Optional[ToolError] = None

    @model_validator(mode="after")
    def validate_result(self) -> "RAGToolResult":
        _validate_error_status(self.status, self.error)
        if self.status == ToolStatus.SUCCESS and not (self.context or self.items):
            raise ValueError("success status requires context or items")
        if self.status == ToolStatus.EMPTY and (self.context or self.items):
            raise ValueError("empty status cannot contain context or items")
        return self


class PubMedToolInput(ContractModel):
    query: QuestionText
    max_results: int = Field(default=5, ge=1, le=50)
    min_year: Optional[int] = Field(default=None, ge=1800, le=9999)


class PubMedArticle(ContractModel):
    pmid: NonEmptyText
    title: str
    authors: str
    journal: str
    year: str
    abstract: str
    url: str


class PubMedToolResult(ContractModel):
    status: ToolStatus
    context: str = ""
    articles: List[PubMedArticle] = Field(default_factory=list)
    error: Optional[ToolError] = None

    @model_validator(mode="after")
    def validate_result(self) -> "PubMedToolResult":
        _validate_error_status(self.status, self.error)
        if self.status == ToolStatus.SUCCESS and not self.articles:
            raise ValueError("success status requires articles")
        if self.status == ToolStatus.EMPTY and (self.context or self.articles):
            raise ValueError("empty status cannot contain context or articles")
        return self


class UserContextProvenance(str, Enum):
    SERVER_VERIFIED = "server_verified"
    UNVERIFIED_CLIENT = "unverified_client"
    NOT_AVAILABLE = "not_available"


class UserContext(ContractModel):
    """Minimal profile snapshot; subject_ref is never accepted as proof of identity."""

    provenance: UserContextProvenance = UserContextProvenance.NOT_AVAILABLE
    subject_ref: Optional[str] = None
    age: Optional[int] = Field(default=None, ge=0, le=130)
    sex: Optional[str] = None
    height_cm: Optional[float] = Field(default=None, gt=0)
    weight_kg: Optional[float] = Field(default=None, gt=0)
    pregnancy_stage: Optional[str] = None


class RecipeIntent(str, Enum):
    CURRENT_PLAN = "current_plan"
    TEMPLATE_CANDIDATES = "template_candidates"
    FOOD_CANDIDATES = "food_candidates"


class RecipeToolInput(ContractModel):
    intent: RecipeIntent
    user_context: Optional[UserContext] = None
    diet_guideline_ids: List[int] = Field(default_factory=list)
    meal_type: Optional[str] = None


class FoodCandidate(ContractModel):
    food_id: Optional[int] = None
    name: Optional[str] = None
    unit: Optional[str] = None
    amount: Optional[float] = None
    meal_type: Optional[str] = None
    remark: Optional[str] = None


class NutritionValue(ContractModel):
    """Optional normalized nutrition data; units must come from the adapter."""

    name: NonEmptyText
    value: float
    unit: Optional[str] = None
    upper_value: Optional[float] = None


class RecipeCandidate(ContractModel):
    recipe_id: Optional[int] = None
    name: Optional[str] = None
    source_kind: Literal["current_plan", "template", "unknown"] = "unknown"
    foods: List[FoodCandidate] = Field(default_factory=list)


class RecipeToolResult(ContractModel):
    status: ToolStatus
    recipes: List[RecipeCandidate] = Field(default_factory=list)
    foods: List[FoodCandidate] = Field(default_factory=list)
    nutrition: List[NutritionValue] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    error: Optional[ToolError] = None

    @model_validator(mode="after")
    def validate_result(self) -> "RecipeToolResult":
        _validate_error_status(self.status, self.error)
        if self.status == ToolStatus.SUCCESS and not (self.recipes or self.foods):
            raise ValueError("success status requires recipes or foods")
        if self.status == ToolStatus.EMPTY and (self.recipes or self.foods):
            raise ValueError("empty status cannot contain recipes or foods")
        return self


class SafetyRestrictionToolInput(ContractModel):
    user_context: Optional[UserContext] = None
    food_ids: List[int] = Field(default_factory=list)
    diet_guideline_ids: List[int] = Field(default_factory=list)


    question: str | None = None
class RestrictionDecision(str, Enum):
    ALLOWED = "allowed"
    BLOCKED = "blocked"
    UNKNOWN = "unknown"


class RestrictionReasonSource(str, Enum):
    DIET_GUIDELINE = "diet_guideline"
    USER_MANUAL = "user_manual"
    UNKNOWN = "unknown"


class RestrictionReason(ContractModel):
    source: RestrictionReasonSource
    message: NonEmptyText
    food_id: Optional[int] = None
    diet_guideline_id: Optional[int] = None


class FoodRestrictionDecision(ContractModel):
    food_id: int
    food_name: Optional[str] = None
    decision: RestrictionDecision
    reasons: List[RestrictionReason] = Field(default_factory=list)


class BlockedFood(ContractModel):
    food_id: int
    food_name: Optional[str] = None


class SafetyRestrictionToolResult(ContractModel):
    status: ToolStatus
    allowed: Optional[bool] = None
    blocked_foods: List[BlockedFood] = Field(default_factory=list)
    decisions: List[FoodRestrictionDecision] = Field(default_factory=list)
    reasons: List[RestrictionReason] = Field(default_factory=list)
    unknown_food_ids: List[int] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    error: Optional[ToolError] = None

    @model_validator(mode="after")
    def validate_result(self) -> "SafetyRestrictionToolResult":
        _validate_error_status(self.status, self.error)
        if self.status == ToolStatus.EMPTY and self.allowed is not None:
            raise ValueError("empty status must leave allowed unknown")
        if self.allowed is True and (self.blocked_foods or self.unknown_food_ids):
            raise ValueError("allowed=true cannot contain blocked or unknown foods")
        return self
