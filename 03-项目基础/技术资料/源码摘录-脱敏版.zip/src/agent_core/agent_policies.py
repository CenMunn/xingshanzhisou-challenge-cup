"""Injectable decision boundaries used by the LangGraph orchestration skeleton.

The policies are deliberately independent from any LLM provider or prompt.
Production implementations can replace the deterministic fakes without changing
the graph topology.
"""

from dataclasses import dataclass
from typing import Protocol, Tuple, runtime_checkable

from .state import AgentIntent, AgentState, SafetyStatus, ToolName


@dataclass(frozen=True)
class SupervisorDecision:
    """Routing decision produced by a supervisor policy."""

    intent: AgentIntent
    required_tools: Tuple[ToolName, ...] = ()


@dataclass(frozen=True)
class SafetyDecision:
    """Safety review result; rejection text is used only for rejected output."""

    status: SafetyStatus
    rejection_text: str | None = None

    def __post_init__(self) -> None:
        if self.status == SafetyStatus.PENDING:
            raise ValueError("a safety policy cannot return pending")
        if self.status == SafetyStatus.REJECT and not self.rejection_text:
            raise ValueError("reject requires rejection_text")


@runtime_checkable
class SupervisorPolicy(Protocol):
    async def decide(self, state: AgentState) -> SupervisorDecision:
        """Classify the request and select only the tools that are needed."""


@runtime_checkable
class NutritionistPolicy(Protocol):
    async def draft(self, state: AgentState) -> str:
        """Build a draft from the question and available tool results."""


@runtime_checkable
class SafetyPolicy(Protocol):
    async def review(self, state: AgentState) -> SafetyDecision:
        """Review a draft and request pass, revision, or rejection."""

