"""Minimal shared state model for a future orchestration graph."""

from enum import Enum
from typing import List, Optional

from pydantic import Field, model_validator

from .contracts import (
    ContractModel,
    PubMedToolResult,
    QuestionText,
    RAGToolResult,
    RecipeToolResult,
    ReferenceRecord,
    SafetyRestrictionToolResult,
    SourceRecord,
    UserContext,
)


class AgentIntent(str, Enum):
    UNKNOWN = "unknown"
    GENERAL_KNOWLEDGE = "general_knowledge"
    RECIPE = "recipe"
    RESTRICTION_CHECK = "restriction_check"


class ToolName(str, Enum):
    RAG = "rag"
    PUBMED = "pubmed"
    RECIPE = "recipe"
    SAFETY_RESTRICTION = "safety_restriction"


class SafetyStatus(str, Enum):
    PENDING = "pending"
    PASS = "pass"
    REVISE = "revise"
    REJECT = "reject"


class AgentStage(str, Enum):
    SUPERVISOR = "supervisor"
    EVIDENCE = "evidence"
    NUTRITIONIST = "nutritionist"
    SAFETY = "safety"
    TOOL = "tool"


class AgentError(ContractModel):
    stage: AgentStage
    code: str
    message: str
    retryable: bool = False


class AgentState(ContractModel):
    request_id: str
    session_id: Optional[str] = None
    question: QuestionText

    intent: AgentIntent = AgentIntent.UNKNOWN
    required_tools: List[ToolName] = Field(default_factory=list)
    user_context: Optional[UserContext] = None

    rag_result: Optional[RAGToolResult] = None
    pubmed_result: Optional[PubMedToolResult] = None
    recipe_result: Optional[RecipeToolResult] = None
    restriction_result: Optional[SafetyRestrictionToolResult] = None

    draft_answer: Optional[str] = None
    final_answer: Optional[str] = None
    sources: List[SourceRecord] = Field(default_factory=list)
    references: List[ReferenceRecord] = Field(default_factory=list)

    safety_status: SafetyStatus = SafetyStatus.PENDING
    errors: List[AgentError] = Field(default_factory=list)
    revision_count: int = Field(default=0, ge=0, le=2)

    @model_validator(mode="after")
    def require_safety_review_for_final_answer(self) -> "AgentState":
        if self.final_answer and self.safety_status in {
            SafetyStatus.PENDING,
            SafetyStatus.REVISE,
        }:
            raise ValueError("final_answer requires a completed safety decision")
        return self
