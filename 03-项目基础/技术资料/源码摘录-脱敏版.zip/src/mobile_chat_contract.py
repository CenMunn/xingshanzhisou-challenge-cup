"""Contracts for the isolated development-only mobile chat Mock."""

from typing import Annotated, Any, List, Literal, Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StrictStr,
    StringConstraints,
    field_validator,
    model_validator,
)


class ContractModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


ConstraintText = Annotated[
    StrictStr, StringConstraints(strip_whitespace=True, min_length=1, max_length=100)
]


class MobileClientContext(ContractModel):
    """Unverified client input; never a trusted user profile."""

    constraints: Optional[List[ConstraintText]] = Field(default=None, max_length=10)


class MobileAgentChatRequest(ContractModel):
    question: StrictStr = Field(max_length=2000)
    session_id: Optional[StrictStr] = Field(default=None, max_length=64)
    client_context: Optional[MobileClientContext] = None

    @model_validator(mode="before")
    @classmethod
    def accept_legacy_query(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value

        normalized = dict(value)
        has_question = "question" in normalized
        has_query = "query" in normalized
        if not has_question and not has_query:
            raise ValueError("question为必填字段")

        if has_question and has_query:
            question = normalized["question"]
            query = normalized["query"]
            if isinstance(question, str) and isinstance(query, str):
                same_content = question.strip() == query.strip()
            else:
                same_content = question == query
            if not same_content:
                raise ValueError("question与query内容不一致")
            normalized.pop("query")
        elif has_query:
            normalized["question"] = normalized.pop("query")

        return normalized

    @field_validator("question", mode="before")
    @classmethod
    def normalize_question(cls, value: object) -> object:
        if isinstance(value, str):
            value = value.strip()
            if not value:
                raise ValueError("question去除首尾空白后不能为空")
        return value


class MockMetadata(ContractModel):
    request_id: str
    session_id: Optional[str] = None
    is_mock: Literal[True] = True


class MockFoodMaterial(ContractModel):
    id: None = None
    name: str
    unit: str


class MockRecipeItem(ContractModel):
    foodMaterialId: None = None
    foodMaterial: MockFoodMaterial
    value: int
    remark: str


class MockRecipe(ContractModel):
    name: str
    remark: str
    infoList: List[MockRecipeItem]


class MockSafety(ContractModel):
    status: Literal["not_evaluated"] = "not_evaluated"
    reasons: List[str]


class MobileAgentChatData(MockMetadata):
    answer: str
    recipes: List[MockRecipe]
    sources: List[str] = Field(default_factory=list)
    references: List[str] = Field(default_factory=list)
    conflict_note: None = None
    safety: MockSafety


class MobileAgentChatResponse(ContractModel):
    success: Literal[True] = True
    code: Literal["200"] = "200"
    message: str = "固定Mock演示数据，仅供联调"
    data: MobileAgentChatData


class MobileAgentChatErrorResponse(ContractModel):
    success: Literal[False] = False
    code: Literal["200"] = "200"
    message: str
    data: MockMetadata


class MockHealthResponse(ContractModel):
    status: Literal["ok"] = "ok"
    service: Literal["mobile-agent-mock"] = "mobile-agent-mock"
    is_mock: Literal[True] = True


# Production responses keep the Mock JSON keys; Mock models remain unchanged.
class AgentFoodMaterial(ContractModel):
    id: Optional[int] = None
    name: Optional[str] = None
    unit: Optional[str] = None


class AgentRecipeItem(ContractModel):
    foodMaterialId: Optional[int] = None
    foodMaterial: AgentFoodMaterial
    value: Optional[float] = None
    remark: Optional[str] = None


class AgentRecipe(ContractModel):
    name: Optional[str] = None
    remark: Optional[str] = None
    infoList: List[AgentRecipeItem]


class AgentSafety(ContractModel):
    status: Literal["pass", "reject", "unavailable", "error"]
    reasons: List[str]


class AgentChatData(ContractModel):
    request_id: str
    session_id: Optional[str] = None
    is_mock: Literal[False] = False
    answer: str
    recipes: List[AgentRecipe] = Field(default_factory=list)
    sources: List[str] = Field(default_factory=list)
    references: List[str] = Field(default_factory=list)
    conflict_note: None = None
    safety: AgentSafety


class AgentChatResponse(ContractModel):
    success: bool
    code: Literal["200", "AGENT_NOT_READY", "AGENT_REJECTED", "AGENT_ERROR", "INVALID_REQUEST"]
    message: str
    data: AgentChatData
